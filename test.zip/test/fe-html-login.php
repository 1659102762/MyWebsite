<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login with your Username</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; 
            align-items: center; 
            height: 100vh;
            background-color: black;
        }

        .register-form {
            width: 700px;
            height: 495px;
            margin-left: -50px;
            border: 2px solid white;
            background: black;
            padding: 20px;
        }
        .register-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .register-form .form-group {
            margin-bottom: 15px;
        }
        .register-form .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .register-form .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .register-form .form-group button {
            width: 100%;
            padding: 15px;
            font-size: 15px;
            margin-top: 20px;
            margin-left: 0px;
            background-color: orange;
            border: none;
            color: white;
            cursor: pointer;
        }
        .register-form .form-group button:hover {
            background-color: orange;
        }
        .toggle-password {
            position: relative;
            left: 659.5px;
            bottom: 47px;
            margin-bottom: -50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .forget-password{
            color: orange;
            position: relative;
            left: 280px;
            bottom: 163px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .no-account{
            color: orange;
            position: relative;
            left: -40px;
            bottom: -40px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .login-byemail{
            color: orange;
            position: relative;
            left: 135px;
            bottom: -5px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div>
        <img src = 'img-eyeOpen.png' alt = 'Toggle Password' wdith = '40' height = '40' 
        id = 'passwordImg' class = 'toggle-password' onclick = "togglePassword('password')">
    </div>
    <div class = 'register-form'>
        <h2> Login </h2>
        <form action = 'be-form-login.php' method = 'post' > 
            <div class = 'form-group'>
                <label for = 'username'>User Name:</label>
                <input type = 'text' id = 'username' name = 'username' 
                placeholder = 'Please enter your username '
                oninvalid="setCustomValidity('Please enter your message');" 
                oninput = "setCustomValidity('');
                saveText('username','username');" required>
                <p id = 'usernameError' style = 'color:black'><br></p>
            </div>
            <div class="form-group">
                <label for = 'password'>Password:</label>
                <input type = "password" id = 'password' name = 'password' 
                placeholder = 'Please enter your password'
                oninvalid="setCustomValidity('Please enter your message');"
                oninput = "setCustomValidity('');" required>
                <p id = 'passwordError' style = 'color:black'><br></p>
            <div class = 'form-group'>
                <button type = 'submit'>Login</button>
                <button type = 'reset'>Reset</button>
            </div>
            <div>
                <a href = "fe-html-forgetPassword.php" class = 'forget-password'>Forget password?</a>
                <a href = "fe-html-email-login.php" class ='login-byemail'>Want login by email?</a>
                <a href = "fe-html-signup.php" class ='no-account'>No account? Want signup?</a>
            </div>
        </form>
    </div>
<?php include 'fe-function-togglePassword.php'; ?>
<?php include 'fe-function-localStorage.php'; ?>
</body>
</html>