<script>
    function checkBeforeSubmit(){
        var ids = ['username','password','confirm password','e-mail'];
        var errorColors = [];
        for (let i = 0;i < ids.length;i++){
            errorColor = document.getElementById(ids[i]+'Error').style.color;
            errorColors.push(errorColor);
        }
        if (errorColors.every(ele => (ele == 'rgb(144, 238, 144)'))){
            return true;
        }
        else{
            alert('Incorrect input');
            return false;
        }

    }
</script>
<script>
    function checkBeforeSubmitForEmailLogin(){
        var ids = ['e-mail','vcode'];
        var errorColors = [];
        for (let i = 0;i < ids.length;i++){
            errorColor = document.getElementById(ids[i]+'Error').style.color;
            errorColors.push(errorColor);
        }
        if (errorColors.every(ele => (ele == 'rgb(144, 238, 144)'))){
            return true;
        }
        else{
            alert('Incorrect input');
            return false;
        }

    }
</script>
<script>
    function checkBeforeSubmitForChangePassword(){
        var ids = ['password','confirm password'];
        var errorColors = [];
        for (let i = 0;i < ids.length;i++){
            errorColor = document.getElementById(ids[i]+'Error').style.color;
            errorColors.push(errorColor);
        }
        if (errorColors.every(ele => (ele == 'rgb(144, 238, 144)'))){
            return true;
        }
        else{
            alert('Incorrect input');
            return false;
        }

    }
</script>
<script>
    function checkBeforeSubmitForForgetPassword(){
        var ids = ['e-mail'];
        var errorColors = [];
        for (let i = 0;i < ids.length;i++){
            errorColor = document.getElementById(ids[i]+'Error').style.color;
            errorColors.push(errorColor);
        }
        if (errorColors.every(ele => (ele == 'rgb(144, 238, 144)'))){
            return true;
        }
        else{
            alert('Incorrect input');
            return false;
        }

    }
</script>