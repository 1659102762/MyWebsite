<script>
    function checkUsernameExist(){
        var inputVal = document.getElementById('username').value;
        $.ajax({
            url: 'be-ajax-checkUsernameExist.php',
            type: 'post',
            dataType: 'json',
            data: {username:inputVal},
            beforeSend: function (){
                document.getElementById('usernameError').textContent = 'Existence Checking...';
                document.getElementById('usernameError').style.color = 'yellow';
            },
            success: function (data){
                var usernameError = document.getElementById('usernameError');         
                if (data.mark == 0){
                    usernameError.textContent =  'Username already exists';
                    usernameError.style.color =  'red';                   
                }
                else{
                    usernameError.textContent =  'Correct';
                    usernameError.style.color =  '#90EE90';
                }
                saveError('usernameError','usernameError');
            },
            error: function (error){
                document.getElementById('usernameError').textContent = 'Ajax error';
                document.getElementById('usernameError').style.color = 'red';   
                console.log(error);
            }
        })
    }

/*
    function checkUsernameExistForLogin(){
        var inputVal = document.getElementById('username').value;
        $.ajax({
            url: 'be-ajax-checkUsernameExist.php',
            type: 'post',
            dataType: 'json',
            data: {username:inputVal},
            beforeSend: function (){
                document.getElementById('usernameError').textContent = 'Existence Checking...';
                document.getElementById('usernameError').style.color = 'yellow';
            },
            success: function (data){
                var usernameError = document.getElementById('usernameError');         
                if (data.mark == 0){
                    usernameError.textContent =  'Username exists, can be used';
                    usernameError.style.color =  '#90EE90';                   
                }
                else{
                    usernameError.textContent =  'Username does not exist';
                    usernameError.style.color =  'red';
                }
                saveError('usernameError','usernameError');
            },
            error: function (error){
                document.getElementById('usernameError').textContent = 'Ajax error';
                document.getElementById('usernameError').style.color = 'red';   
                console.log(error);
            }
        })
    }
*/
</script>



        
