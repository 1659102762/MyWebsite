<script>
    function checkEmailExist(){
        var inputVal = document.getElementById('e-mail').value;
        $.ajax({
            url: 'be-ajax-checkEmailExist.php',
            type: 'post',
            dataType: 'json',
            data: {'e-mail':inputVal},
            beforeSend: function (){
                document.getElementById('e-mailError').textContent = 'Existence Checking...';
                document.getElementById('e-mailError').style.color = 'yellow';
            },
            success: function (data){  
                var emailError = document.getElementById('e-mailError');         
                if (data.mark == 0){
                    emailError.textContent =  'E-mail already exists';
                    emailError.style.color =  'red';
                }
                else{
                    emailError.textContent =  'Correct';
                    emailError.style.color =  '#90EE90';
                }
                saveError('e-mailError','e-mailError');
            },
            error: function (error){
                document.getElementById('e-mailError').textContent = 'Ajax error';
                document.getElementById('e-mailError').style.color = 'red';  
                console.log(error);
            }
        })
    }

/*
    function checkEmailExistForLogin(){
        var inputVal = document.getElementById('e-mail').value;
        $.ajax({
            url: 'be-ajax-checkEmailExist.php',
            type: 'post',
            dataType: 'json',
            data: {'e-mail':inputVal},
            beforeSend: function (){
                document.getElementById('e-mailError').textContent = 'Existence Checking...';
                document.getElementById('e-mailError').style.color = 'yellow';
            },
            success: function (data){  
                var emailError = document.getElementById('e-mailError');         
                if (data.mark == 0){
                    emailError.textContent =  'E-mail exists, can be used';
                    emailError.style.color =  '#90EE90';
                }
                else{
                    emailError.textContent =  'E-mail does not exist';
                    emailError.style.color =  'red';
                }
                saveError('e-mailError','e-mailError');
            },
            error: function (error){
                document.getElementById('e-mailError').textContent = 'Ajax error';
                document.getElementById('e-mailError').style.color = 'red';  
                console.log(error);
            }
        })
    }
*/
</script>