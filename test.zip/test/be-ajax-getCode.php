<?php
// Start session
session_start();

// Introduce the files of phpmailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Recieve the email data sent from the ajax in frontend
$em =$_POST['em'];

//Define an empty array as the data going to be return to frontend
$ret = array();

// check if email input exist and return '$ret['emailExist']' to control frontend
if (isset($_SESSION['loggingIdForEmailLogin'])){
    $ret['emailExist'] = 1;
    $id = $_SESSION['loggingIdForEmailLogin'];
}
else{
    $ret['emailExist'] = -1;
    echo json_encode($ret);
    exit;
}

// Randomly generate verification code of 6-digit number 
$vcode = '';
for ($i = 0; $i < 6; $i++) {
    $vcode .= rand(0, 9); 
}
$_SESSION['correctVcode'] = $vcode;


// Define instance of class 'PHPMailer'
$mail = new PHPMailer(true);
try {
    // Server smtp settings
    $mail-> CharSet   = 'UTF-8';               
    $mail->isSMTP();                                            
    $mail->Host       = 'smtp.gmail.com';                    
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'wang.yiyang.p5@alumni.tohoku.ac.jp';                                               
    $mail->Password   = 'lvfdtxzboaklufht';                              
    $mail->SMTPSecure =  'ssl';          
    $mail->Port       = 465; 
                                     
    // Set the sender and receiver
    $mail->setFrom('wang.yiyang.p5@alumni.tohoku.ac.jp', 'wyy');
    $mail->addAddress($em,'abc');               

    // Define the content of mail
    $mail->isHTML(true);                                  
    $mail->Subject = 'Your one-time verification code arrives';
    $mail->Body    = "Your one-time verification code is: <b>$vcode</b><br>Please use this code to log in your account.";

    $mail->send();
    $ret['sendResult'] = 1;   // '$ret['sendResult']' returned to frontend to decide if the mail is successfully sent
} catch (Exception $e) {
    $ret['sendResult'] = $mail->ErrorInfo;
}

// Return data to front end with json format
echo json_encode($ret);
?>
