<?php
$un = $_POST['username'];
$pwb = $_POST['passwordBefore'];
$pw = $_POST['password'];
$pwhash = password_hash($pw,PASSWORD_DEFAULT);


// Connect database.
try {
    $pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo 'Database Connection succeeds';
} catch(PDOException $e) {
    echo 'Database Connection fails: ' . $e->getMessage();
    exit;
}


$sql = "SELECT * FROM `wyy`.`signup-info` WHERE `username` = '$un'";
$res = $pdo -> query($sql);
$count = $res -> rowCount();
if (!$count){
    echo "<script>alert('Username does not exist');history.back();</script>";
    exit;
}
$strRes = $res->fetch(PDO::FETCH_ASSOC);
$pwbhash = $strRes['password'];
$id = $strRes['id'];
$nlogin = $strRes['nlogin'];
$VerificationBenchmark = 3;

$nlogin += 1;
$pdo -> query("UPDATE `wyy`.`signup-info` SET `nlogin` = $nlogin  WHERE `id` = '$id'");

if ($nlogin >= $VerificationBenchmark){
    echo "<script>alert('Please drag the square to the most right side to confirm you are not robot');
    location.href = 'fe-html-verification-drag.php';</script>";
    exit;
}

if(!password_verify($pwb,$pwbhash)){
    echo "<script>alert('Incorrect password before');history.back();</script>";
    exit;
}
else{
    $sql = "UPDATE `wyy`.`signup-info` SET `password` = '$pwhash' WHERE `id` = '$id'";
    $pdo -> query($sql);
    $nlogin = 0;
    $pdo -> query("UPDATE `wyy`.`signup-info` SET `nlogin` = $nlogin  WHERE `id` = '$id'");
    echo "<script>alert('modification succeeds');location.href = 'fe-html-top.php';</script>";
}
?>