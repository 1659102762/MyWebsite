<script>
    function checkUsernameExistChangePassword(){
        var inputVal = document.getElementById('username').value;
        $.ajax({
            url: 'be-ajax-checkUsernameExist.php',
            type: 'post',
            dataType: 'json',
            data: {username:inputVal},
            beforeSend: function (){
                document.getElementById('usernameError').textContent = 'Existence Checking...';
                document.getElementById('usernameError').style.color = 'yellow';
            },
            success: function (data){
                var usernameError = document.getElementById('usernameError');         
                if (data.mark == 1){
                    usernameError.textContent =  'Username does not exist';
                    usernameError.style.color =  'red';                   
                }
                else{
                    usernameError.textContent =  'Username registered';
                    usernameError.style.color =  '#90EE90';
                }
                saveError('usernameError','usernameError');
            },
            error: function (error){
                document.getElementById('usernameError').textContent = 'Ajax error';
                document.getElementById('usernameError').style.color = 'red';   
                console.log(error);
            }
        })
    }
</script>