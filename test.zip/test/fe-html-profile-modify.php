<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; 
            align-items: center; 
            height: 100vh;
            background-color: black;
        }

        .register-form {
            width: 700px;
            height: 850px;
            margin-left: -80px;
            border: 2px solid white;
            background: black;
            padding: 20px;
        }
        .register-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .register-form .form-group {
            margin-bottom: 15px;
        }
        .register-form .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .register-form .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .register-form .form-group textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .register-form .form-group select {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .register-form .form-group button {
            font-size: 15px;
            width: 100%;
            padding: 15px;
            margin-top: 20px;
            margin-left: 0px;
            background-color: orange;
            border: none;
            color: white;
            cursor: pointer;
        }
        .register-form .form-group button:hover {
            background-color: orange;
        }
        .what-is-these{
            color: orange;
            position: relative;
            left: 133px;
            bottom: -1px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class = 'register-form'>
        <h2>Profile</h2>
        <form>
            <div class = 'form-group' style = 'margin-bottom:-15px;'>
            <label for  = 'nickname'>Nickname:</label>
            <input type = 'text' id = 'nickname' name = 'nickname' placeholder = 'Just name the way you like'><br><br>
            <p id ='nicknameError'><br></p>
            </div>
            <div class = 'form-group'>
            <label for = 'gender'>Gender:</label>
            <select id="gender" name = 'gender'>
                <option value = ''>Select your gender</option>
                <option value = 'male'>Male</option>
                <option value = 'female'>Female</option>
                <option value = 'other'>Others</option>
            </select>
            <p><br></p>
            </div>
            <p></p>
            <div class = 'form-group' style = 'margin-bottom: 15px;'>
            <label for = 'age'>Age:</label>
            <input type = 'number' id = 'age' name = 'age' placeholder = 'Tell us your age'>
            <p><br></p>
            </div>
            <div>
            <label for="Preference">Preference:</label><br>
            <p></p>
            <input type = "checkbox" id = 'red sea' name = 'pref[]' value = 'red sea'>
            <span style = 'color: #FF6347'>Red Sea</span>
            <input type = "checkbox" id = 'blue sea' name = 'pref[]' value = 'blue sea'>
            <span style = 'color: #ADD8E6'>Blue Sea</span>
            <input type = "checkbox" id = 'green sea' name = 'pref[]' value = 'green sea'>
            <span style = 'color: #90EE90'>Green Sea</span>
            <input type = "checkbox" id = 'purple sea' name = 'pref[]' value = 'purple sea'>
            <span style = 'color: #E0B0FF'>Purple Sea</span>
            <a class ='what-is-these' onmouseover = "setCustomValidity('123')">← What is these?</a>
            <p><br></p>
            </div>
            <div class = 'form-group'>
            <label for = 'introduction'>Self-Introduction:</label>
            <textarea id = 'introduction' name = 'introduction' rows = '9' 
            placeholder = 'Introduce yourself to everybody in magic tower comunity'></textarea>
            </div>
            <div class = 'form-group'>
            <button type = 'submit' >Modify</button>
            <p></p>
            <button type = 'reset' >Reset</button>
            </div>
        </form>
    </div>
</body>
</html>

