<?php
    session_start();
    $status = $_POST['status'];
    $id = $_SESSION['loggedId'];
    $pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
    $sql = "UPDATE `wyy`.`signup-info` SET `status` = '$status' WHERE `id` = '$id'";
    $pdo -> query($sql);
    unset($_SESSION['loggedUsername']);
    echo json_encode($status);
?>