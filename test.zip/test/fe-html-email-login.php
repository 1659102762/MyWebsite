<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login with your E-mail</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; 
            align-items: center; 
            height: 100vh;
            background-color: black;
        }

        .register-form {
            width: 700px;
            height: 470px;
            margin-left: -135px;
            border: 2px solid white;
            background: black;
            padding: 20px;
        }
        .register-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .register-form .form-group {
            margin-bottom: 15px;
        }
        .register-form .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .register-form .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .register-form .form-group button {
            width: 100%;
            padding: 15px;
            font-size: 15px;
            margin-top: 20px;
            margin-left: 0px;
            background-color: orange;
            border: none;
            color: white;
            cursor: pointer;
        }
        .register-form .form-group button:hover {
            background-color: orange;
        }
        .toggle-password {
            position: relative;
            left: 496.5px;
            bottom: 35px;
            margin-bottom: -50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .no-account{
            color: orange;
            position: relative;
            left: 125px;
            bottom: 80px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .get-code{
            position: relative;
            height: 35px;
            width: 80px;
            left: 628px;
            bottom: 18.5px;
            font-size: 15px;
            background-color: orange;
            border: none;
            color: white;
            cursor: pointer;
        }
        .login-byusername{
            color: orange;
            position: relative;
            left: 128px;
            bottom: 25px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div>
        <button class = 'get-code' onclick = "getCode();">Get code</button>
    </div>
    <div>
        <img src = 'img-eyeOpen.png' alt = 'Toggle Password' wdith = '40' height = '40' 
        id = 'vcodeImg' class = 'toggle-password' onclick = "togglePassword('vcode')">
    </div>
    <div class = 'register-form'>
        <h2> E-mail Login </h2>
        <form action = 'be-form-email-login.php' method = 'post' onsubmit = "return checkBeforeSubmitForEmailLogin();"> 
            <div class = 'form-group'>
                <label for = 'e-mail'>E-mail:</label>
                <input type = 'text' id = 'e-mail' name = 'e-mail' 
                placeholder = 'Please enter your e-mail '
                oninvalid="setCustomValidity('Please enter your message');" 
                oninput = "setCustomValidity('');checkEmailExistForEmailLogin();saveText('e-mail','e-mail');" required>
                <p id = 'e-mailError'><br></p>
            </div>
            <div class="form-group">
                <label for = 'vcode'>Verification Code:</label>
                <input type = 'password' id = 'vcode' name = 'vcode' 
                placeholder = 'Please enter the verification code you received'
                oninvalid="setCustomValidity('Please enter your message');"
                oninput = "setCustomValidity('');" required>
                <p id = 'vcodeError'><br></p>
            </div>
            <div class = 'form-group'>
                <button type = 'submit'>Login</button>
                <button type = 'reset'>Reset</button>
            </div>
            <div class = 'no-account'>
                <a href = "fe-html-signup.php" class ='no-account'>No account? Want signup?</a>
            </div>
            <div class = 'login-byusername'>
                <a href = "fe-html-login.php" class ='login-byusername'>Want login by username?</a>
            </div>
        </form>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('e-mail').value = localStorage.getItem('e-mail');
        checkEmailExistForEmailLogin();
    });
</script>
<?php include 'fe-function-togglePassword.php'; ?>
<?php include 'fe-function-localStorage.php'; ?>
<script src="https://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
<?php include 'fe-ajax-checkEmailExist-email-login.php'; ?>
<?php include 'fe-function-checkBeforeSubmit.php'; ?>
<?php include 'fe-ajax-getCode.php'; ?>

</body>
</html>