<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>个人信息页面</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
        }
        .info {
            margin-bottom: 20px;
        }
        .info p {
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>个人信息</h1>
        <div class="info">
            <p><strong>姓名：</strong>张三</p>
            <p><strong>年龄：</strong>30岁</p>
            <p><strong>职业：</strong>软件工程师</p>
            <p><strong>联系方式：</strong>电话：1234567890, 邮箱：zhangsan@example.com</p>
        </div>
    </div>
</body>
</html>