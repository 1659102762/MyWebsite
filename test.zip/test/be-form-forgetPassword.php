<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$em = $_POST['e-mail'];

if (isset($_SESSION['loggingIdForEmailLogin'])){
    $id = $_SESSION['loggingIdForEmailLogin'];
}
else{
    exit;
}

function generatePassword($length = 20) {
    $number = '0123456789';
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $special = '!@#$%^&*()_-+=~`|{}[]:;<>,.?/';
    $numberLength = strlen($number);
    $lowercaseLength = strlen($lowercase);
    $uppercaseLength = strlen($uppercase);
    $specialLength = strlen($special);
    $randomString = '';
    for ($i = 0; $i < $length/4; $i++) {
        $randomString .= $number[random_int(0, $numberLength - 1)];
    }
    for ($i = $length/4; $i < 2*$length/4; $i++) {
        $randomString .= $lowercase[random_int(0, $lowercaseLength - 1)];
    }
    for ($i = 2*$length/4; $i < 3*$length/4; $i++) {
        $randomString .= $uppercase[random_int(0, $uppercaseLength - 1)];
    }
    for ($i = 3*$length/4; $i < 4*$length/4; $i++) {
        $randomString .= $special[random_int(0, $specialLength - 1)];
    }
    return $randomString;
}
 
$tpw = generatePassword(20);


$mail = new PHPMailer(true);
try {
        //Server settings
    $mail-> CharSet   = 'UTF-8';
    $mail->SMTPDebug  = 1;                      
    $mail->isSMTP();                                            
    $mail->Host       = 'smtp.gmail.com';                     
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'wang.yiyang.p5@alumni.tohoku.ac.jp';                                               
    $mail->Password   = 'lvfdtxzboaklufht';                              
    $mail->SMTPSecure =  'ssl';          
    $mail->Port       = 465;                                   
    //Recipients
    $mail->setFrom('wang.yiyang.p5@alumni.tohoku.ac.jp', 'wyy');
    $mail->addAddress($em,'abc');               

    //Content
    $mail->isHTML(true);                                  
    $mail->Subject = 'Your temporary password arrives';
    $mail->Body    = "Your temporary password is: <b>$tpw</b><br>Please save this password and had better modify it.";

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

$tpwhash = password_hash($tpw,PASSWORD_DEFAULT);

$pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
$pdo -> query("UPDATE `wyy`.`signup-info` SET `password` = '$tpwhash' WHERE `id` = $id");

echo "<script>alert('Your tempory password already sent, Please check your e-mail');history.back();</script>";
?>
