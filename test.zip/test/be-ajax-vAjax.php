<?php
// Start session
session_start();


// Recieve the 'vpassed' data sent from the ajax in frontend
$vpassed = $_POST['vpassed'];


// Get id through session stored in 'be-form-login.php'
$id = $_SESSION['loggingId'];


// If verification succeeds, reset 'nlogin' into 0, or else do nothing
if ($vpassed == 1){
    $pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
    $pdo -> query("UPDATE `wyy`.`signup-info` SET `nlogin` = 0 WHERE `id` = '$id'");
}

//Return data to front end with json format
echo json_encode($vpassed);
?>