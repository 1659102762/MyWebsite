!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>We will send temporary password to your e-mail</title>
</head>
<body>
<button id="myButton" disabled>点击我 (5)</button>
<span id="countdown"></span>
</body>
<script>
document.getElementById('myButton').addEventListener('click', function() {
    // 禁用按钮并显示倒计时
    this.disabled = true;
    const duration = 5; // 倒计时时间（秒）
    let counter = duration;
    this.textContent = '点击我 (' + counter + ')';
    document.getElementById('countdown').textContent = counter + '秒后可用';
 
    // 设置定时器，每秒减少一次计数并更新按钮文本和倒计时显示
    const timer = setInterval(() => {
        counter--;
        this.textContent = '点击我 (' + counter + ')';
        document.getElementById('countdown').textContent = counter + '秒后可用';
        if (counter <= 0) {
            clearInterval(timer); // 清除定时器
            this.disabled = false; // 重新启用按钮
            this.textContent = '点击我'; // 重置按钮文本
            document.getElementById('countdown').textContent = ''; // 清空倒计时显示
        }
    }, 1000); // 每1000毫秒（1秒）更新一次
});
</script>
<html>