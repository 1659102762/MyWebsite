<script>
    function alreadySentMessage(){
        var This = document.getElementById('vcodeError')
        This.style.color = '#90EE90';
        This.textContent = 'Code Already sent, Please check your email';
    }
</script>