<?php
// Start session
session_start();


// Get data from frontend ajax through 'post'
$em = $_POST['e-mail'];


// Define empty array to return
$ret = array();


//Destroy previous id session
unset($_SESSION['loggingIdForEmailLogin']);


// Connect database
$pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
$sql = "SELECT * FROM `wyy`.`signup-info` WHERE `e-mail` = '$em'";
$res = $pdo -> query($sql);
$count = $res -> rowCount();


// If the data with this username in database exists, extract its Id and save it into session and return ret['mark'] to control frontend
 if ($count){
    $ret['mark'] = 1;
    $strRes = $res->fetch(PDO::FETCH_ASSOC);
    $id = $strRes['id'];
    $_SESSION['loggingIdForEmailLogin'] = $id;
}
else{
    $ret['mark'] = 0;
}


// Return data in json format
echo json_encode($ret);
?>