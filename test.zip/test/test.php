<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$adminemail = "wang.yiyang.p5@alumni.tohoku.ac.jp";

$to = "wang.yiyang.p5@alumni.tohoku.ac.jp";
$mail = new PHPMailer;
$mail->isSMTP();

/*Outlook host is smtp.office365.com*/
$mail->Host = "smtp.gmail.com";
$mail->Port = "465";
/*tls true*/
$mail->SMTPSecure = 'ssl';
$mail->SMTPAuth   = true;
$mail->Username = $adminemail;
$mail->Password = 'lvfdtxzboaklufht';                             


/* setfrom and username should be always same */
$mail->setFrom($adminemail);
$mail->addAddress($to); 
$mail->Subject = "test email";
$mail->msgHTML("<h1>Testing body</h1>");
if (!$mail->send()) {
	echo "Mailer Error";
	echo "<pre>";
	print_r($mail);
	die('fail');
}else{
	echo "success";
	die('done');
}