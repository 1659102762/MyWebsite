<?php
    session_start();
    $vpassed = $_POST['vpassed'];
    $id = $_SESSION['loggingIdForEmailLogin'];
    if ($vpassed == 1){
        $pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
        $pdo -> query("UPDATE `wyy`.`signup-info` SET `nlogin` = 0 WHERE `id` = '$id'");
    }
    echo json_encode($vpassed);
?>