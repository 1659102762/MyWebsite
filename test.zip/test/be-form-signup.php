<?php

$un = $_POST['username'];
$pw = $_POST['password'];
$em = $_POST['e-mail'];

$pwhash = password_hash($pw,PASSWORD_DEFAULT);


// Connect database.
try {
  $pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo 'Database Connection succeeds';
} catch(PDOException $e) {
  echo 'Database Connection fails: ' . $e->getMessage();
  exit;
}

$sql = "INSERT INTO `wyy`.`signup-info` (`username`, `password`, `e-mail`, `created time`,`status`) 
VALUES ('$un','$pwhash','$em','".time()."','off')";
$res = $pdo -> query($sql);
if ($res){
    echo "<script>alert('Signup succeeds');location.href = 'fe-html-login.php';</script>";
}
else{
    echo "<script>alert('Signup fails');history.back(); </script>";
    exit;
}
?>