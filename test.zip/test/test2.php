<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

try {
        //Server settings
    $mail-> CharSet   = 'UTF-8';
    $mail->SMTPDebug  = 1;                      
    $mail->isSMTP();                                            
    $mail->Host       = 'smtp.gmail.com';                     
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'wang.yiyang.p5@alumni.tohoku.ac.jp';                                               
    $mail->Password   = 'lvfdtxzboaklufht';                              
    $mail->SMTPSecure =  'ssl';          
    $mail->Port       = 465;                                   
    //Recipients
    $mail->setFrom('wang.yiyang.p5@alumni.tohoku.ac.jp', 'wyy');
    $mail->addAddress('aaa1659102762@outlook.com','abc');               

    //Content
    $mail->isHTML(true);                                  
    $mail->Subject = 'Your Verification code arrives';
    $mail->Body    = "Your verification code is: <b>fucker</b><br>Please use this code to log in your account.";

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo $mail->ErrorInfo;
}
?>