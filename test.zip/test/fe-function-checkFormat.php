<script>    
    let unFormat = /^[a-zA-Z0-9]{3,20}$/;
    let pwFormat = /^(?=.*?[a-z])(?=.*?[A-Z])(?=.*?\d)(?=.*?[*?!&￥$%^#,./@";:><\[\]}{\-=+_\\|》《。，、？’‘“”~ `]).{10,50}$/;
    let emFormat = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,320}$/;
    function checkFormat(id){
        var inputVal = document.getElementById(id).value;
        if (id == 'username'){
            var error = document.getElementById('usernameError');
            if (!unFormat.test(inputVal)){
                error.style.color = 'red';
                error.textContent = 'Incorrect format';
                return false;
            }
            else{
                error.style.color = '#90EE90';//light green
                error.textContent = 'Correct';
                return true;
            }
        }
        if (id == 'password' || id == 'confirm password'){
            var pwInputVal = document.getElementById('password').value;
            var pwError = document.getElementById('passwordError');
            var cpwInputVal = document.getElementById('confirm password').value;
            var cpwError = document.getElementById('confirm passwordError');
            if (!pwFormat.test(pwInputVal)){
                pwError.style.color = 'red';
                pwError.textContent = 'Incorrect format';

            }
            else if (pwInputVal != cpwInputVal){
                    pwError.textContent = 'Correct format but inconsistent password and confirm password';
                    pwError.style.color = 'red';
                    cpwError.style.color = 'red';
                    cpwError.textContent = 'Inconsistent password and confirm password';
            }
            else{
                pwError.style.color = '#90EE90';//light green
                pwError.textContent = 'Correct';
                cpwError.style.color = '#90EE90';//light green
                cpwError.textContent = 'Correct';
            }
        }
        if (id == 'e-mail'){
            var error = document.getElementById('e-mailError');
            if (!emFormat.test(inputVal)){
                error.style.color = 'red';
                error.textContent = 'Incorrect format';
                return false;
            }
            else{
                error.style.color = '#90EE90';//light green
                error.textContent = 'Correct';
                return true;
            }
        }

    }
</script>