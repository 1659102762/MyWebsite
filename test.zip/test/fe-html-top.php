<?php session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top</title>
    <style> 
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            font-size: 20px;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
        }

        nav ul a {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        main {
            padding: 20px;
        }

        aside {
            background-color: #f4f4f4;
            padding: 10px;
            margin-top: 20px;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <!-- 网站头部，包含导航栏 -->
        <nav>
            <ul>
                <li>
                    <a href = "fe-html-top.php" >Top</a>
                    <a href = "fe-html-signup.php">Signup</a>
                    <?php if (isset($_SESSION['loggedUsername']) && $_SESSION['loggedUsername'] <> ''){ ?>
                    <a id = 'logout'  href = 'fe-html-top.php' onclick = "logoutAjax('off');">Logout</a>  
                    <?php }else{ ?>
                    <a href = "fe-html-login.php">Login</a>   
                    <?php } ?>
                    <a href = "fe-html-changePassword.php">Modify Password</a>
                    <a href = "fe-html-forgetPassword.php">Forget Password</a>
                    <a href = "https://h5mota.com/tower/?name=xinxin2new">Play Towers</a>
                    <a href = "https://h5mota.com/tower/?name=xinxin2new">Create Towers</a>
                    <a href = "https://h5mota.com/tower/?name=xinxin2new">Forum</a>
                </li>
            </ul>
        </nav>
    </header>
    
    <main>
        <!-- 主要内容区域 -->
        <section id = "home">
        <?php if (isset($_SESSION['loggedUsername']) && $_SESSION['loggedUsername'] <> ''){ ?>
            <h1>Welcome <span style = 'color:orange;font-size:50px;'><?php echo $_SESSION['loggedUsername'];?> </span>  to the World of Magic Tower!</h1>
        <?php }else{ ?>
            <h1>Welcome to the World of Magic Tower!</h1>
            <?php } ?>
            <p>This is a web site for playing creating and discussing series games of Magic Tower.</p>
        </section>
        
        <!-- 其他内容区域，可以根据需要添加 -->
        <!-- <section id="about">...</section> -->
        <!-- <section id="services">...</section> -->
        <!-- <section id="contact">...</section> -->
    </main>
    
    <aside>
        <!-- 侧边栏，可以包含其他功能或链接 -->
        <h2></h2>
        <ul>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </aside>
    
    <footer>
        <!-- 网站底部信息 -->
        <p></p>
    </footer>
<script src="https://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
<?php include 'fe-ajax-logoutAjax.php'; ?>
</body>
</html>

