<?php
// Start session
session_start();


// Get frontend data in form by 'post'
$un = $_POST['username'];
$pw = $_POST['password'];


// Connect database.
try {
    $pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo 'Database Connection succeeds';
} catch(PDOException $e) {
    echo 'Database Connection fails: ' . $e->getMessage();
    exit;
}


// use $un to select all the info of this user in database
$sql = "SELECT * FROM `wyy`.`signup-info` WHERE `username` = '$un'";
$res = $pdo -> query($sql);
$count = $res -> rowCount();
if (!$count){
    echo "<script>alert('Username does not exist');history.back();</script>";
    exit;
}


//Use fetch() to ge the array of selected info and extract $id and $nlogin
$strRes = $res->fetch(PDO::FETCH_ASSOC);
$pwhash = $strRes['password'];
$id = $strRes['id'];
$nlogin = $strRes['nlogin'];


// store $id into session as logging id, this is done to transmit $id into another php file for the convenience of sql query.
$_SESSION['loggingId'] = $id;


// Set how many times of logins will cause drag verification. 
$VerificationBenchmark = 3;


// Upadte 'nlogin' with every login
$nlogin += 1;
$pdo -> query("UPDATE `wyy`.`signup-info` SET `nlogin` = $nlogin  WHERE `id` = '$id'");


// Below executes when user already login. the existence of $_SESSION['loggedUsername'] represents whether user already logins or not
if ($_SESSION['loggedUsername'] == $un){
    echo "<script>alert('Username already logs in');</script>";
    echo "<script>location.href = 'fe-html-top.php';</script>";
    exit;
}


// When 'nlogin' gets to the benchmark, drag verification occurs
if ($nlogin >= $VerificationBenchmark){
    echo "<script>alert('Please drag the square to the most right side to confirm you are not robot');
    location.href = 'fe-html-verification-drag.php';</script>";
    exit;
}


// check if the password input by user in consistent with the hash value of password stored in database
if(!password_verify($pw,$pwhash)){
    echo "<script>alert('Incorrect password');history.back();</script>";
    exit;
}
// If login succeeds, 'nlogin' reset into 0, and meanwhile destroy the sessions with keys 'loggingId'
else{
    $nlogin = 0;
    $pdo -> query("UPDATE `wyy`.`signup-info` SET `nlogin` = $nlogin  WHERE `id` = '$id'");

    // Meanwhile, update the login status
    $sql = "UPDATE `wyy`.`signup-info` SET `status` = 'on' WHERE `id` = '$id'";
    $pdo -> query($sql); 
    echo "<script>alert('Login succeeds');</script>";
    echo "<script>location.href = 'fe-html-top.php';</script>";
    unset($_SESSION['loggingId']);
}


//Define sesssion below to represent whether user already logins or not
$_SESSION['loggedUsername'] = $un;
$_SESSION['loggedId'] = $id;
?>