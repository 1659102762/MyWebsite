<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>We will send temporary password to your e-mail</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; 
            align-items: center; 
            height: 100vh;
            background-color: black;
        }

        .register-form {
            width: 700px;
            height: 350px;
            margin-left: -25px;
            border: 2px solid white;
            background: black;
            padding: 20px;
        }
        .register-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .register-form .form-group {
            margin-bottom: 15px;
        }
        .register-form .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .register-form .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .register-form .form-group button {
            width: 50%;
            padding: 15px;
            font-size: 15px;
            margin-top: 20px;
            margin-left: 167px;
            background-color: orange;
            border: none;
            color: white;
            cursor: pointer;
        }
        .register-form .form-group button:hover {
            background-color: orange;
        }
        .toggle-password {
            position: relative;
            left: 496.5px;
            bottom: 35px;
            margin-bottom: -50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .no-account{
            color: orange;
            position: relative;
            left: 250px;
            bottom: -5px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .get-code{
            position: relative;
            height: 35px;
            width: 80px;
            left: 628px;
            bottom: 18.5px;
            font-size: 15px;
            background-color: orange;
            border: none;
            color: white;
            cursor: pointer;
        }
        .gofor-login{
            color: orange;
            position: relative;
            left: 300px;
            bottom: -5px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class = 'register-form'>
        <h2> Send Temporary Password to Your E-mail </h2>
        <form action = 'be-form-forgetPassword.php' method = 'post' onsubmit = "return checkBeforeSubmitForForgetPassword();"> 
            <div class = 'form-group'>
                <label for = 'e-mail'>E-mail:</label>
                <input type = 'text' id = 'e-mail' name = 'e-mail' 
                placeholder = 'Please enter your e-mail '
                oninvalid="setCustomValidity('Please enter your message');" 
                oninput = "setCustomValidity('');checkEmailExistForEmailLogin();saveText('e-mail','e-mail');" required>
                <p id = 'e-mailError'><br></p>
            </div>
            <div class = 'form-group'>
                <button type = 'submit'>Send email</button>
                <button type = 'reset'>Reset</button>
            </div>
            <div>
                <a href = "fe-html-login.php" class ='gofor-login'>Go for login</a>
            </div>
        </form>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('e-mail').value = localStorage.getItem('e-mail');
        checkEmailExistForEmailLogin();
    });
</script>
<?php include 'fe-function-togglePassword.php'; ?>
<?php include 'fe-function-localStorage.php'; ?>
<script src="https://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
<?php include 'fe-ajax-checkEmailExist-email-login.php'; ?>
<?php include 'fe-function-checkBeforeSubmit.php'; ?>
<?php include 'fe-ajax-getCode.php'; ?>

</body>
</html>