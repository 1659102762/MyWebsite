<script>
    function logoutAjax(status){
        $.ajax({
            url: 'be-ajax-logoutAjax.php',
            type: 'post',
            dataType: 'json',
            data: {'status': status},
            success: function (data){      
            },
            error: function (error){
                alert('Ajax error');
                console.log(error);
            }
        })
    }
</script>