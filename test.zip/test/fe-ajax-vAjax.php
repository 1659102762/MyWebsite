<script>
    function vAjax(vpassed){
        $.ajax({
            url: 'be-ajax-vAjax.php',
            type: 'post',
            dataType: 'json',
            data: {'vpassed': vpassed},
            success: function (data){
            },
            error: function (error){
                console.log(error);
            }
        })
    }
</script>
<script>
    function vAjaxForEmailLogin(vpassed){
        $.ajax({
            url: 'be-ajax-vAjax-email-login.php',
            type: 'post',
            dataType: 'json',
            data: {'vpassed': vpassed},
            success: function (data){
            },
            error: function (error){
                console.log(error);
            }
        })
    }
</script>