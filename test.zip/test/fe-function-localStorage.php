<script>
        window.onload = function() {
            var t = document.title;
            if (t == 'Signup with us'){
                loadText('username','username');
                loadText('e-mail','e-mail');
            }
            if (t == 'Login with your E-mail' || t == 'We will send temporary password to your e-mail'){
                loadText('e-mail','e-mail');
            }
            if (t == 'Modify Your Password' || t == 'Login with your Username'){
                loadText('username','username');
            }
        }

        function saveText(key,id) {
            var value = document.getElementById(id).value;
            localStorage.setItem(key, value);
        }
        function saveError(key,id) {
            var error = document.getElementById(id).textContent;
            var color = document.getElementById(id).style.color;
            var tc = [error, color];
            var strtc = JSON.stringify(tc);
            localStorage.setItem(key, strtc);
        }

        function loadText(key,id) {
            if (localStorage.getItem(key)){
                var value = localStorage.getItem(key);
                var color = localStorage.getItem(key);
                if (value) {
                    document.getElementById(id).value = value;
                }
            }
        }
        function loadError(key,id) {
            if (localStorage.getItem(key)){
                var error = JSON.parse(localStorage.getItem(key))[0];
                var color = JSON.parse(localStorage.getItem(key))[1];
                if (error) {
                    document.getElementById(id).textContent = error;
                }
                if (color){
                    document.getElementById(id).style.color = color;
                }
            }
        }
    </script>