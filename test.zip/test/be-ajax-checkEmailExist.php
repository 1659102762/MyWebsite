<?php
$em = $_POST['e-mail'];
$ret = array();

$pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
$sql = "SELECT * FROM `wyy`.`signup-info` WHERE `e-mail` = '$em'";
$res = $pdo -> query($sql);
$count = $res -> rowCount();
if ($count){
    $ret['mark'] = 0;
}
else{
    $ret['mark'] = 1;
}

echo json_encode($ret);
?>