<script>
    function getCode(){
        // Get the input value of email by id
        var em = document.getElementById('e-mail').value;
        $.ajax({
            url: 'be-ajax-getCode.php', // Set the url of api
            type: 'post',               // Set 'post' as the method api receive data from frontend
            dataType: 'json',           // Set the format of data transmission as 'json'
            data: {'em':em},            // Define the data transmitted from frontend

            // Instruct what to do before the request and response succeed
            beforeSend: function (){               
                document.getElementById('vcodeError').textContent = 'Code being sent...';
                document.getElementById('vcodeError').style.color = 'yellow';
            },
            
            // Instruct what to do after succeed
            success: function (data){               
                var vcode = document.getElementById('vcodeError');
                if(data.emailExist == -1){
                    vcode.textContent = 'E-mail does not exist';
                    vcode.style.color = 'red';
                }
                else{
                    vcode.textContent = 'Code already sent, Please check your email';
                    vcode.style.color = '#90EE90';
                }

                if (data.sendResult){
                    if (data.sendResult == 1){
                        vcode.textContent = 'Code already sent, Please check your email';
                        vcode.style.color = '#90EE90';
                    }
                    else{
                        vcode.textContent = 'Sending Code fails';
                        vcode.style.color = 'red';
                        alert('ErrorInfo: ' + data.sendResult);
                    }
                }
            },
            
            // Instruct what to do if fails
            error: function (error){            
                document.getElementById('vcodeError').textContent = 'Ajax Error';
                document.getElementById('vcodeError').style.color = 'red';
                console.log(error);
            }
        })
    }
</script>