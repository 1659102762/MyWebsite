<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Verification-drag</title>
<style>
    body {
        font-family: Arial, sans-serif;
        color: white;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center; 
        align-items: center; 
        height: 100vh;
        background-color: white;
        }
    #slider {
        width: 300px;
        height: 50px;
        background-color: #ccc;
        position: relative;
  }
    #target {
        width: 50px;
        height: 50px;
        background-color: orange;
        position: relative;
        cursor: pointer;
  }
    .button{
        height:50px;
        margin-left:0px;
        color:white;
        background-color: orange;
    }
</style>
</head>
<body>
 
<div id="slider">
  <div id="target"></div>
</div>

<script src="https://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
<?php include 'fe-ajax-vAjax.php'; ?>
<script>
  var slider = document.getElementById('slider');
  var target = document.getElementById('target');
  var initialX = 0;
  var isDragging = false;
  var vpassed = -1; //vpassed -1 represents verification unpassed and 1 is  verification passed
  vAjax(vpassed);  // the variable 'vpassed' is sent through ajax into api
 
  slider.addEventListener('mousedown', function(e) {
    initialX = e.clientX - target.offsetLeft;
    isDragging = true;
  });
 
  document.addEventListener('mousemove', function(e) {
    if (isDragging) {
      var x = e.clientX - initialX;
      if (x > 0 && x + 50 <= slider.offsetWidth) { // Make sure the square move within a fixed range
        target.style.left = x + 'px';
      }
    }
  });
  document.addEventListener('mouseup', function() {
    isDragging = false;
    if (target.offsetLeft >= slider.offsetWidth - 50) { // If the square get to the most right side of slider, the verification passed
      vpassed = 1;
      vAjax(vpassed);  //If verification succeeds, send it to api
      alert('Verification succeeds');
      history.back();
      
    } else {
      target.style.left = '0px'; // If fails, reset to initial status and alert.
      alert('Please drag the square to the most right sides');
    }
  });
</script>
</body>
</html>