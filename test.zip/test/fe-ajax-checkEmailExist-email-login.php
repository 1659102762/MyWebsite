<script>
    function checkEmailExistForEmailLogin(){
        var inputVal = document.getElementById('e-mail').value;
        $.ajax({
            url: 'be-ajax-checkEmailExist-email-login.php',
            type: 'post',
            dataType: 'json',
            data: {'e-mail':inputVal},
            beforeSend: function (){
                document.getElementById('e-mailError').textContent = 'Existence Checking...';
                document.getElementById('e-mailError').style.color = 'yellow';
            },
            success: function (data){  
                var emailError = document.getElementById('e-mailError');         
                if (data.mark == 1){
                    emailError.textContent =  'E-mail exist, can be used';
                    emailError.style.color =  '#90EE90';
                }
                else{
                    emailError.textContent =  'E-mail does not exist';
                    emailError.style.color =  'red';
                }
                saveError('e-mailError','e-mailError');
            },
            error: function (error){
                document.getElementById('e-mailError').textContent = 'Ajax error';
                document.getElementById('e-mailError').style.color = 'red';  
                console.log(error);
            }
        })
    }
</script>