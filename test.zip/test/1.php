<?php/*
use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';

    $mail = new PHPMailer(true);

    $vcode = '';
    for ($i = 0; $i < 6; $i++) {
        $vcode .= rand(0, 9); 
    }

    try {
        //Server settings
        $mail-> CharSet   = 'UTF-8';
        $mail->SMTPDebug  = 1;                      
        $mail->isSMTP();                                            
        $mail->Host       = 'smtp.gmail.com';                     
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = 'wang.yiyang.p5@alumni.tohoku.ac.jp';                                               
        $mail->Password   = 'lvfdtxzboaklufht';                              
        $mail->SMTPSecure =  'ssl';          
        $mail->Port       = 465;                                   
        //Recipients
        $mail->setFrom('wang.yiyang.p5@alumni.tohoku.ac.jp', 'wyy');
        $mail->addAddress('aaa1659102762@outlook.com','abc');               

        //Content
        $mail->isHTML(true);                                  
        $mail->Subject = 'Your Verification code arrives';
        $mail->Body    = "Your verification code is: <b>$vcode</b><br>Please use this code to log in your account.";

        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
*/?>

2025-02-03 14:14:09 CLIENT -&gt; SERVER: EHLO www.wyy.com<br>\n2025-02-03 14:14:10 CLIENT -&gt; SERVER: AUTH LOGIN<br>\n2025-02-03 14:14:10 CLIENT -&gt; SERVER: [credentials hidden]<br>\n2025-02-03 14:14:10 CLIENT -&gt; SERVER: [credentials hidden]<br>\n2025-02-03 14:14:10 CLIENT -&gt; SERVER: MAIL FROM:&lt;wang.yiyang.p5@alumni.tohoku.ac.jp&gt;<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: RCPT TO:&lt;aaa1659102762@outlook.com&gt;<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: DATA<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: Date: Mon, 3 Feb 2025 22:14:09 +0800<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: To: abc &lt;aaa1659102762@outlook.com&gt;<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: From: wyy &lt;wang.yiyang.p5@alumni.tohoku.ac.jp&gt;<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: Subject: Your Verification code arrives<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: Message-ID: &lt;a11mUjS1eW31AJw0WwmjNXTLpcEFR8zwLJ09tk46li8@www.wyy.com&gt;<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: X-Mailer: PHPMailer 6.9.3 (https://github.com/PHPMailer/PHPMailer)<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: MIME-Version: 1.0<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: Content-Type: text/html; charset=UTF-8<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: <br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: Your verification code is: &lt;b&gt;292805&lt;/b&gt;&lt;br&gt;Please use this code to log in your account.<br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: <br>\n2025-02-03 14:14:11 CLIENT -&gt; SERVER: .<br>\n2025-02-03 14:14:12 CLIENT -&gt; SERVER: QUIT<br>\n{\"$emailExist\":1,\"sendResult\":1}"
setRequestHeader
: 
ƒ (e,t)
state
: 
ƒ ()
status
: 
200
statusCode
: 
ƒ (e)
statusText
: 
"OK"
success
: 
ƒ ()
then
: 
ƒ ()
[[Prototype]]
: 
Object

if (data.sendResult = 1){
                    document.getElemntById('e-mailError').textCntent = 'Code Already sent, Please check your email';
                    document.getElemntById('e-mailError').color = '#90EE90';
                }
                else{
                    document.getElemntById('e-mailError').textCntent = 'Sending Code fails';
                    document.getElemntById('e-mailError').color = 'red';
                }