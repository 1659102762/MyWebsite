<script>
    function togglePassword(id){
        var inputThis = document.getElementById(id);
        var imgThis = document.getElementById(id + 'Img');
        if (inputThis.type == 'password'){
            inputThis.type = 'text';
            imgThis.src = 'img-eyeClose.png';
        }
        else{
            inputThis.type = 'password';
            imgThis.src = 'img-eyeOpen.png';
        }
    }
</script>