<?php
//stat session
session_start();

// Get frontend data by 'post'
$em = $_POST['username'];
$vcode = $_POST['vcode'];


// Connect database.
try {
    $pdo = new PDO('mysql:host=localhost;dbname=wyy;charset=utf8mb4', 'root', '12345678');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo 'Database Connection succeeds';
} catch(PDOException $e) {
    echo 'Database Connection fails: ' . $e->getMessage();
    exit;
}


// Receive user id from 'be-ajax-checkEmailExist-emial-login.php'
$id = $_SESSION['loggingIdForEmailLogin'];


// Receive the verification code from 'be-ajax-checkEmailExist-emial-login.php'
$correctVcode = $_SESSION['correctVcode'];


// Use id to select all the infos of user, extract the data of 'nlogin' and 'username'
$sql = "SELECT * FROM `wyy`.`signup-info` WHERE `id` = '$id'";
$res = $pdo -> query($sql);
$strRes = $res->fetch(PDO::FETCH_ASSOC);
$nlogin = $strRes['nlogin'];
$un = $strRes['username'];


// Set how many number of logins will cause drag verification. 
$VerificationBenchmark = 3;


// Upadte 'nlogin' with every login
$nlogin += 1;
$pdo -> query("UPDATE `wyy`.`signup-info` SET `nlogin` = $nlogin  WHERE `id` = '$id'");


// Below executes when user already login
if ($_SESSION['loggedUsername']){
    echo "<script>alert('Username already logs in');</script>";
    echo "<script>location.href = 'fe-html-top.php';</script>";
    exit;
}


// When 'nlogin' gets to the benchmark, drag verification occurs
if ($nlogin >= $VerificationBenchmark){
    echo "<script>alert('Please drag the square to the most right side to confirm you are not robot');
    location.href = 'fe-html-verification-drag-email-login.php';</script>";
    exit;
}


// Check if the verification code input is consistent with the verification code system sent
if($vcode != $correctVcode){
    echo "<script>alert('Incorrect verification code');</script>";
    echo "<script>history.back();</script>";
    exit;
}
// If login succeeds, 'nlogin' reset into 0, and meanwhile destroy the sessions with keys 'loggingIdForEmailLogin' and 'correctVcode'
else{
    $nlogin = 0;
    $pdo -> query("UPDATE `wyy`.`signup-info` SET `nlogin` = $nlogin  WHERE `id` = '$id'");
    echo "<script>alert('Login succeeds');location.href = 'fe-html-top.php';</script>";
    unset($_SESSION['loggingIdForEmailLogin']);
    unset($_SESSION['correctVcode']);
}


// Meanwhile, update the login status
$sql = "UPDATE `wyy`.`signup-info` SET `status` = 'on' WHERE `id` = '$id'";
$pdo -> query($sql); 


//Define sesssion below to represent whether user already logins or not
$_SESSION['loggedUsername'] = $un;
$_SESSION['loggedId'] = $id;
?>