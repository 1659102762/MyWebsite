<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup with us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; 
            align-items: center; 
            height: 100vh;
            background-color: black;
        }

        .register-form {
            width: 700px;
            height: 650px;
            margin-left: -80px;
            border: 2px solid white;
            background: black;
            padding: 20px;
        }
        .register-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .register-form .form-group {
            margin-bottom: 15px;
        }
        .register-form .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .register-form .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .register-form .form-group button {
            font-size: 15px;
            width: 100%;
            padding: 15px;
            margin-top: 20px;
            margin-left: 0px;
            background-color: orange;
            border: none;
            color: white;
            cursor: pointer;
        }
        .register-form .form-group button:hover {
            background-color: orange;
        }
        .toggle-password {
            position: relative;
            left: 670px;
            bottom: 125px;
            margin-bottom: -50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .toggle-confirmpassword {
            position: relative;
            left: 630px;
            bottom: 16px;
            margin-bottom: -50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
        .have-account{
            color: orange;
            position: relative;
            left: 215px;
            bottom: 163px;
            margin-bottom: 50px;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div>
        <img src = 'img-eyeOpen.png' alt = 'Toggle Password' wdith = '40' height = '40' 
        id = 'passwordImg' class = 'toggle-password' onclick = "togglePassword('password')">
    </div>
    <div>
        <img src = 'img-eyeOpen.png' alt = 'Toggle ConfirmPassword' wdith = '40' height = '40' 
        id = 'confirm passwordImg' class='toggle-confirmpassword' onclick = "togglePassword('confirm password')">
    </div>
    <div class = 'register-form'>
        <h2> Registration </h2>
        <form action = 'be-form-signup.php' method = 'post' 
        onsubmit = "return checkBeforeSubmit();" > 
            <div class = 'form-group'>
                <label for = 'username'>User Name:</label>
                <input type = 'text' id = 'username' name = 'username'
                placeholder = 'Username within length range [3,20] with only lowercase or upper case or number'
                oninvalid="setCustomValidity('Please enter your message');" 
                oninput = "setCustomValidity('');if (checkFormat('username')){checkUsernameExist();}
                saveText('username','username');"
                required>
                <p id = 'usernameError'><br></p>
            </div>
            <div class="form-group">
                <label for = 'password'>Password:</label>
                <input type = "password" id = 'password' name = 'password' value = ''
                placeholder = 'Password within length range [8,50] with both lowercase, uppercase, number and special mark'
                oninvalid = "setCustomValidity('Please enter your message');"
                oninput = "setCustomValidity('');checkFormat('password');" required>
                <p id = 'passwordError' ><br></p>
            </div>
            <div class="form-group">
                <label for = 'confirm password'>Confirm Password:</label>
                <input type = 'password' id = 'confirm password' name = 'confirm password' value = ''
                placeholder = 'Please enter your password again'
                oninvalid="setCustomValidity('Please enter your message');"
                oninput = "setCustomValidity('');checkFormat('confirm password');" required>
                <p id = 'confirm passwordError'><br></p>
            </div>
            <div class="form-group">
                <label for = 'e-mail'>E-mail:</label>
                <input type = 'text' id = 'e-mail' name = 'e-mail'
                placeholder = 'Please enter your e-mail within 320 characters'
                oninvalid="setCustomValidity('Please enter your message');"
                oninput = "setCustomValidity('');if (checkFormat('e-mail')){checkEmailExist();};
                saveText('e-mail','e-mail');" 
                required>
                <p id = 'e-mailError'><br></p>
            </div>
            <div class = 'form-group'>
                <button type = 'submit'>Signup</button>
                <button type = 'reset'>Reset</button>
            </div>
            <div>
                <a href = "fe-html-login.php" class ='have-account'>Already have account? Go for login</a>
            </div>
        </form>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('username').value = localStorage.getItem('username');
        if (checkFormat('username')){
            checkUsernameExist();
        }
        document.getElementById('e-mail').value = localStorage.getItem('e-mail');
        if (checkFormat('e-mail')){
            checkEmailExist();
        }
    });
</script>
<?php include 'fe-function-checkFormat.php'; ?>
<?php include 'fe-function-togglePassword.php'; ?>
<?php include 'fe-function-localStorage.php'; ?>
<?php include 'fe-function-checkBeforeSubmit.php'; ?>
<script src="https://libs.baidu.com/jquery/1.9.1/jquery.min.js"></script>
<?php include 'fe-ajax-checkUsernameExist.php'; ?>
<?php include 'fe-ajax-checkEmailExist.php'; ?>

</body>
</html>

